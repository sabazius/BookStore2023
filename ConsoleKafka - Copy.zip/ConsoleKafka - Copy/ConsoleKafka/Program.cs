﻿using Confluent.Kafka;
using ConsoleKafka.Kafka;

namespace ConsoleKafka
{
    internal class Program
    {
        private static KafkaConsumer _consumer;
        private static KafkaProducer _producer;
        private static string _user;

        static void Main(string[] args)
        {
            Console.WriteLine("Goodbye!");
        }
    }
}
